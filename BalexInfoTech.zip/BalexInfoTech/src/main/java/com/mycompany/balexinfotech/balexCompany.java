/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.balexinfotech;

/**
 *
 * @author user
 */
public class balexCompany {

    public static void calculatePay(double basePay, int hoursWorked) {
        
        if (basePay < 8.00) {
            System.out.println("Error: Base pay is below the minimum wage.");
            return;
        }
        
       
        if (hoursWorked > 60) {
            System.out.println("Error: Hours worked exceeds the maximum allowed.");
            return;
        }

        double totalPay;

        
        if (hoursWorked <= 40) {
            totalPay = hoursWorked * basePay;
        } else {
            int overtimeHours = hoursWorked - 40;
            totalPay = (40 * basePay) + (overtimeHours * basePay * 1.5);
        }

        System.out.println("Total pay: $" + totalPay);
    }

   
    public static void main(String[] args) {
       
        double[][] employees = {
            {7.50, 35}, 
            {8.20, 47},  
            {10.00, 73}  
        };

       
        for (double[] employee : employees) {
            System.out.println("Base Pay: $" + employee[0] + ", Hours Worked: " + (int)employee[1]);
            calculatePay(employee[0], (int) employee[1]);
            System.out.println("-------------------");
        }
    }
}